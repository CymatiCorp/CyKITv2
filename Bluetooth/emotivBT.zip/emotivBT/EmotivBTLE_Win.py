#
#  Designed for Bluetooth LE on Windows 8/10
#
#  Author:  CaptainSmiley
#

import binascii
import os
from time import sleep
from ctypes import *
from ctypes.wintypes import HRESULT, HANDLE, ULONG, DWORD, USHORT


DEVICE_UUID = "{81072f40-9f3d-11e3-a9dc-0002a5d5c51b}"
DATA_UUID = "{81072f41-9f3d-11e3-a9dc-0002a5d5c51b}"
MEMS_UUID = "{81072f42-9f3d-11e3-a9dc-0002a5d5c51b}"



class BTH_LE_GATT_CHARACTERISTIC_VALUE(Structure):
    _fields_ = [
        ("DataSize", c_ulong),
        ("Data", c_ubyte * 20)]         #  this is a hack - 20-bytes should be dynamic, not preallocated



#  -------------------------------------------------------------------

#
#  FUNCTION:  DataCallback
#  PURPOSE:   This function is called whenever the bluetooth device sends new
#             information from the headset
#
_CB_FUNC_ = CFUNCTYPE(None, BTH_LE_GATT_CHARACTERISTIC_VALUE)
def DataCallback(EventOutParameter):
    print binascii.hexlify(EventOutParameter)
    


def RunApp():
    dir_path = os.path.dirname(os.path.realpath(__file__))
    eegDll = cdll.LoadLibrary(dir_path + "\\EEGBtleLib\\Release\\EEGBtleLib.dll")
    
#    uuid_list = [unicode(DATA_UUID), unicode(MEMS_UUID)]
    uuid_list = [unicode(DATA_UUID)]
    uuid_clist = (c_wchar_p * len(uuid_list))()
    uuid_clist[:] = uuid_list

    #  initialize the dll engine; pass it the UUID of the device we want to connect too
    hDev = eegDll.btle_init(unicode(DEVICE_UUID))

    #  set the callback function to handle the updates
    cb_func = _CB_FUNC_(DataCallback)
    eegDll.set_callback_func(cb_func)

    #  start the data collection; pass it the list of UUID characteristics we are
    #  interested in
    eegDll.run_data_collection(hDev, uuid_clist)
    
    for x in range(0, 5):
        sleep(0.1)

    #  disconnect from the device
    eegDll.btle_disconnect(hDev)
    print "Done"

    return 0


if __name__ == "__main__":
    RunApp()
