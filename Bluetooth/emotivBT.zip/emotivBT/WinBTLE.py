#
#  Designed for Bluetooth LE on Windows 8/10
#
#  Author:  CaptainSmiley
#           Pieced together from a lot of different web sources including:
#               https://github.com/joric/bluetooth-battery-monitor/blob/master/bluetooth_battery_monitor.py
#               https://gist.github.com/tshirtman/44e8efeefb2c59ec017e
#               https://social.msdn.microsoft.com/Forums/vstudio/en-US/bad452cb-4fc2-4a86-9b60-070b43577cc9/is-there-a-simple-example-desktop-programming-c-for-bluetooth-low-energy-devices?forum=wdk
#
#       *** This script doesnt work, but someone with more python/ctypes experience can probably
#           figure out how to fix it.  Would be advantagous to use this approach as opposed to
#           creating a seperate DLL ***
#

from ctypes import *
from ctypes.wintypes import HRESULT, HANDLE, LPCWSTR, DWORD, WORD, BYTE, WCHAR, USHORT, BOOL, BOOLEAN


S_OK = 0x0
ERROR_SUCCESS = 0x0
INVALID_HANDLE_VALUE = c_void_p(-1).value

GENERIC_READ = 0x80000000
GENERIC_WRITE = 0x40000000
FILE_SHARE_READ = 0x00000001
FILE_SHARE_WRITE = 0x00000002
OPEN_EXISTING = 0x3
ERROR_MORE_DATA = 234

DIGCF_PRESENT = 0x00000002
DIGCF_DEVICEINTERFACE = 0x00000010
BLUETOOTH_GATT_FLAG_NONE = 0x00000000

DEVICE_UUID = "{81072f40-9f3d-11e3-a9dc-0002a5d5c51b}"
DATA_UUID = "{81072f41-9f3d-11e3-a9dc-0002a5d5c51b}"
MEMS_UUID = "{81072f42-9f3d-11e3-a9dc-0002a5d5c51b}"

WIN = windll.user32
OLE = oledll.ole32
SAPI = windll.Setupapi
BAPI = windll.BluetoothAPIs
WBAS = windll.Kernel32


#  ---------------------------------------------------------------------------------------



def new(structure, **kwargs):
    s = structure()
    for k, v in kwargs.items(): setattr(s, k, v)
    return s


class SP_DEVICE_INTERFACE_DETAIL_DATA(Structure):
    _fields_ = [
    ("cbSize", DWORD),
    ("DevicePath", c_wchar * 1)]


class GUID(Structure):
    _fields_ = [
        ("Data1", DWORD),
        ("Data2", WORD),
        ("Data3", WORD),
        ("Data4", c_byte * 8)]

    def __init__(self, name=None):
        if name is not None:
            self._as_parameter = OLE.CLSIDFromString(unicode(name), byref(self))

    def __unicode__(self):
        p = c_wchar_p()
        OLE.StringFromCLSID(byref(self), byref(p))
        result = p.value
        OLE.CoTaskMemFree(p)
        return result
    __str__ = __unicode__


class BTH_LE_UUID(Structure):
    _pack_ = 2;
    _fields_ = [
        ("IsShortUuid", BOOL),
        ("ShortUuid", USHORT),
        ("LongUuid", GUID)]


class BTH_LE_GATT_SERVICE(Structure):
    _fields_ = [
        ("ServiceUuid", BTH_LE_UUID),
        ("AttributeHandle", USHORT)]


class SP_DEVICE_INTERFACE_DATA(Structure):
    _fields_ = [
        ("cbSize", DWORD),
        ("InterfaceClassGuid", GUID),
        ("Flags", DWORD),
        ("Reserved", POINTER(c_ulong))]


class SP_DEVINFO_DATA(Structure):
    _fields_ = [
        ("cbSize", DWORD),
        ("ClassGuid", GUID),
        ("DevInst", DWORD),
        ("Reserved", POINTER(c_ulong))]


class BTH_LE_GATT_CHARACTERISTIC(Structure):
    _fields_ = [
        ("ServiceHandle", USHORT),
        ("CharacteristicUuid", BTH_LE_UUID),
        ("AttributeHandle", USHORT),
        ("CharacteristicValueHandle", USHORT),
        ("IsBroadcastable", BOOLEAN),
        ("IsReadable", BOOLEAN),
        ("IsWritable", BOOLEAN),
        ("IsWritableWithoutResponse", BOOLEAN),
        ("IsSignedWritable", BOOLEAN),
        ("IsNotifiable", BOOLEAN),
        ("IsIndicatable", BOOLEAN),
        ("HasExtendedProperties", BOOLEAN)]


class SP_DEVICE_INTERFACE_DETAIL_DATA(Structure):
    _fields_ = [
        ("cbSize", DWORD),
        ("DevicePath", WCHAR * 1)]


class BLUETOOTH_GATT_VALUE_CHANGED_EVENT_REGISTRATION(Structure):
    _fields_ = [
        ("NumCharacteristics", USHORT),
        ("Characteristics", BTH_LE_GATT_CHARACTERISTIC * 1)]


class BLUETOOTH_GATT_EVENT_CALLBACK(Structure):
    _fields_ = [
#        ("EventType", BTH_LE_GATT_EVENT_TYPE),
        ("EventOutParameter", c_void_p),
        ("Context", c_void_p)]



#  ------------------------------------------------------------------------------------------

CALLBACKPROC = WINFUNCTYPE(DWORD, c_void_p, c_void_p)
EventCallbackProc = CALLBACKPROC



@EventCallbackProc
def EventNotificationCallback(EventType, EventOutParameter, Context):
    print "Event callback called!"
    

def HRESULT_FROM_WIN32(x):
    FACILITY_WIN32 = 7
    # make signed
    from ctypes import c_long
    x = c_long(x).value
#    if x < 0:
#        return x
    return (0x80000000 | FACILITY_WIN32 << 16 | x & 0xFFFF)
#    return c_long(0x80070000 | (x & 0xFFFF)).value



def GetBLEHandle():
    AGuid = GUID(DEVICE_UUID)
    found = False
    
    hDI = SAPI.SetupDiGetClassDevsW(byref(AGuid), 0, 0, DIGCF_PRESENT | DIGCF_DEVICEINTERFACE)
    if hDI == INVALID_HANDLE_VALUE:
        print "Problem with SetupDiGetClassDevsW"
        return -1
    else:
        print "HDI: %x" % hDI

    did = SP_DEVICE_INTERFACE_DATA(sizeof(SP_DEVICE_INTERFACE_DATA))
    devInfo = SP_DEVINFO_DATA(sizeof(SP_DEVINFO_DATA))

    i = DWORD(0).value    
    while(SAPI.SetupDiEnumDeviceInterfaces(hDI, None, byref(AGuid), i, byref(did))):
        i += 1
        dwSize = DWORD(0)
        SAPI.SetupDiGetDeviceInterfaceDetailW(hDI, byref(did), None, 0, byref(dwSize), 0)
        devDetail = SP_DEVICE_INTERFACE_DETAIL_DATA()
        resize(devDetail, dwSize.value)
        devDetail.cbSize = sizeof(SP_DEVICE_INTERFACE_DETAIL_DATA) - sizeof(WCHAR * 1)
        SAPI.SetupDiGetDeviceInterfaceDetailW(hDI, byref(did), byref(devDetail), dwSize, byref(dwSize), byref(devInfo))
        path = wstring_at(byref(devDetail, sizeof(DWORD)))
        print path
        found = True

        if found == True:
            break

    if found:
        hComm = WBAS.CreateFileW(
            path,
            GENERIC_READ,
            FILE_SHARE_READ | FILE_SHARE_WRITE,
            None,
            OPEN_EXISTING,
            0,
            None)

        if hComm == INVALID_HANDLE_VALUE:
            raise WinError()
        else:
            print hex(hComm)
    
        SAPI.SetupDiDestroyDeviceInfoList(hDI)
        return hComm

    SAPI.SetupDiDestroyDeviceInfoList(hDI)
    return -1
    


def SetupBluetoothDevice(hLEDevice):
    print hex(hLEDevice)

    svcBufCount = USHORT()
    resSvc = BAPI.BluetoothGATTGetServices(hLEDevice, 0, None, byref(svcBufCount), BLUETOOTH_GATT_FLAG_NONE)
    if resSvc == ERROR_MORE_DATA:
        print "hmmm... odd"
        print resSvc
        print svcBufCount
    else:
        print "services found"

    pSvcBuffer = new(BTH_LE_GATT_SERVICE * svcBufCount.value)   
    numServices = DWORD()
    resSvc = BAPI.BluetoothGATTGetServices(hLEDevice,
                                           svcBufCount,
                                           byref(pSvcBuffer),
                                           byref(svcBufCount),
                                           BLUETOOTH_GATT_FLAG_NONE)
    if resSvc != S_OK:
        raise WinError()

    print "Number of services: %d" % svcBufCount.value
    for currSvcBuf in pSvcBuffer:
        charBufCount = USHORT(0)
        resCh = BAPI.BluetoothGATTGetCharacteristics(hLEDevice,
                                                 byref(currSvcBuf),
                                                 0,
                                                 None,
                                                 byref(charBufCount),
                                                 BLUETOOTH_GATT_FLAG_NONE)
        
        pCharBuffer = new(BTH_LE_GATT_CHARACTERISTIC * charBufCount.value)
        numChars = USHORT(0)
        resCh = BAPI.BluetoothGATTGetCharacteristics(hLEDevice,
                                                 byref(currSvcBuf),
                                                 charBufCount,
                                                 byref(pCharBuffer),
                                                 byref(numChars),
                                                 BLUETOOTH_GATT_FLAG_NONE)

        if resCh != S_OK:
            raise WinError()

        print "Number of characteristics: %d" % numChars.value

        for currChar in pCharBuffer:
            pBuf = GUID(unicode(currChar.CharacteristicUuid.LongUuid))
            tmpUuid = str(pBuf)
            
            if (tmpUuid.upper() == DATA_UUID.upper()) or (tmpUuid.upper() == MEMS_UUID.upper()):
                print pBuf
                if currChar.IsNotifiable:
                    print "\tCharacteristic is notifiable"
                    EventHandle = HANDLE(0)
                    EventType = DWORD(0)           #  BTH_LE_GATT_EVENT_TYPE value
                    EventParameterIn = BLUETOOTH_GATT_VALUE_CHANGED_EVENT_REGISTRATION()
                    EventParameterIn.NumCharacteristics = 1
                    EventParameterIn.Characteristics[0] = currChar

                    ####  PROBLEM WITH INVALID PARAMETER HERE  ####
                    resRe = BAPI.BluetoothGATTRegisterEvent(hLEDevice,
                                                            EventType,
                                                            byref(EventParameterIn),
                                                            EventNotificationCallback,
                                                            None,
                                                            byref(EventHandle),
                                                            BLUETOOTH_GATT_FLAG_NONE)
                    if resRe == S_OK:
                        print "\tEvent notification set"
                    else:
                        print "\tEvent notification NOT set :0x%X" % HRESULT_FROM_WIN32(resRe)
                                                            
                else:
                    print "\tCharacteristic is NOT notifiable"
                

    return 0


def RunApp():

    hComm = GetBLEHandle()
    if hComm == -1:
        print "Problem getting handle"
        return -1
    
    SetupBluetoothDevice(hComm)
    
    WBAS.CloseHandle(hComm)

    return 0


if __name__ == "__main__":
    RunApp()
